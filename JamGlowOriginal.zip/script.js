// ---------- Product Data ----------
const PRODUCTS = [
  {
    id: "suit_01",
    name: "Coral Reef One-Piece",
    price: 4800,
    size: "Sizes S–XL",
    note: "Supportive one-piece swimsuit with Caribbean-inspired print."
  },
  {
    id: "goggles_01",
    name: "WaveGuard Pro Goggles",
    price: 2500,
    size: "Adjustable strap",
    note: "Anti-fog, UV-protected goggles for pool and open water."
  },
  {
    id: "float_01",
    name: "Island Breeze Floatie",
    price: 3200,
    size: "Adult size",
    note: "Durable inflatable floatie for rivers, pools, and beach days."
  }
];

const CART_KEY = "jamglow_cart";
const CHECKOUT_KEY = "jamglow_checkout";

// ---------- Helpers ----------
function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: "smooth" });
  }
}

function loadCart() {
  try {
    const stored = localStorage.getItem(CART_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch (e) {
    return {};
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

// ---------- Products / Home ----------
function renderProducts() {
  const grid = document.getElementById("product-grid");
  if (!grid) return;

  grid.innerHTML = "";
  PRODUCTS.forEach((product) => {
    const card = document.createElement("article");
    card.className = "product-card";
    card.innerHTML = `
      <h3>${product.name}</h3>
      <p>${product.note}</p>
      <div class="product-meta">
        <span class="product-price">$${product.price.toFixed(2)} JMD</span>
        <span class="product-size">${product.size}</span>
      </div>
      <div class="product-actions">
        <button class="btn primary" type="button" data-id="${product.id}">Add to Cart</button>
        <button class="btn ghost" type="button" onclick="scrollToSection('cart')">View Cart</button>
      </div>
    `;
    grid.appendChild(card);
  });

  grid.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-id]");
    if (!btn) return;
    const id = btn.getAttribute("data-id");
    addToCart(id);
  });
}

function addToCart(productId) {
  const cart = loadCart();
  cart[productId] = (cart[productId] || 0) + 1;
  saveCart(cart);
  alert("Item added to cart.");
  renderCart();
  renderSummary();
}

// ---------- Cart ----------
function renderCart() {
  const tbody = document.getElementById("cart-items");
  if (!tbody) return;

  const cart = loadCart();
  tbody.innerHTML = "";

  let subtotal = 0;
  Object.entries(cart).forEach(([id, qty]) => {
    const product = PRODUCTS.find((p) => p.id === id);
    if (!product) return;
    const lineTotal = product.price * qty;
    subtotal += lineTotal;
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${product.name}</td>
      <td>${product.price.toFixed(2)}</td>
      <td><input type="number" min="0" value="${qty}" data-id="${id}"></td>
      <td>${lineTotal.toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });

  let discount = subtotal >= 8000 ? subtotal * 0.1 : 0;
  let tax = (subtotal - discount) * 0.15;
  let total = subtotal - discount + tax;

  const format = (n) => n.toFixed(2);

  const subEl = document.getElementById("cart-subtotal");
  const discEl = document.getElementById("cart-discount");
  const taxEl = document.getElementById("cart-tax");
  const totalEl = document.getElementById("cart-total");

  if (subEl) subEl.textContent = format(subtotal);
  if (discEl) discEl.textContent = format(discount);
  if (taxEl) taxEl.textContent = format(tax);
  if (totalEl) totalEl.textContent = format(total);

  // Handle quantity changes
  tbody.addEventListener("change", (e) => {
    const input = e.target;
    if (input.tagName.toLowerCase() !== "input") return;
    const id = input.getAttribute("data-id");
    let value = parseInt(input.value, 10);
    if (isNaN(value) || value < 0) value = 0;

    const updated = loadCart();
    if (value === 0) {
      delete updated[id];
    } else {
      updated[id] = value;
    }
    saveCart(updated);
    renderCart();
    renderSummary();
  });
}

function clearCart() {
  localStorage.removeItem(CART_KEY);
  renderCart();
  renderSummary();
}

function goToCheckout() {
  scrollToSection("checkout");
}

// ---------- Checkout Summary ----------
function renderSummary() {
  const cart = loadCart();
  let subtotal = 0;
  Object.entries(cart).forEach(([id, qty]) => {
    const product = PRODUCTS.find((p) => p.id === id);
    if (!product) return;
    subtotal += product.price * qty;
  });
  let discount = subtotal >= 8000 ? subtotal * 0.1 : 0;
  let tax = (subtotal - discount) * 0.15;
  let total = subtotal - discount + tax;

  const format = (n) => n.toFixed(2);

  const subEl = document.getElementById("summary-subtotal");
  const discEl = document.getElementById("summary-discount");
  const taxEl = document.getElementById("summary-tax");
  const totalEl = document.getElementById("summary-total");

  if (subEl) subEl.textContent = format(subtotal);
  if (discEl) discEl.textContent = format(discount);
  if (taxEl) taxEl.textContent = format(tax);
  if (totalEl) totalEl.textContent = format(total);
}

function calculateTotals(cart) {
  let subtotal = 0;
  Object.entries(cart).forEach(([id, qty]) => {
    const product = PRODUCTS.find((p) => p.id === id);
    if (!product) return;
    subtotal += product.price * qty;
  });
  let discount = subtotal >= 8000 ? subtotal * 0.1 : 0;
  let tax = (subtotal - discount) * 0.15;
  let total = subtotal - discount + tax;
  return { subtotal, discount, tax, total };
}

// ---------- Checkout & Invoice ----------
function handleCheckout(event) {
  event.preventDefault();
  const form = event.target;
  const formData = new FormData(form);
  const data = Object.fromEntries(formData.entries());
  const cart = loadCart();

  const payload = {
    cart,
    totals: calculateTotals(cart),
    customer: {
      name: data["ship_name"],
      address: data["ship_address"],
      phone: data["ship_phone"]
    },
    payment: {
      method: data["payment_method"],
      amountPaid: parseFloat(data["amount_paid"] || "0")
    },
    createdAt: new Date().toISOString()
  };

  localStorage.setItem(CHECKOUT_KEY, JSON.stringify(payload));
  renderInvoice();
  scrollToSection("invoice");
}

function renderInvoice() {
  const raw = localStorage.getItem(CHECKOUT_KEY);
  const data = raw ? JSON.parse(raw) : null;
  if (!data) return;

  const { cart, totals, customer, payment, createdAt } = data;
  const itemsBody = document.getElementById("invoice-items");
  if (!itemsBody) return;

  itemsBody.innerHTML = "";
  Object.entries(cart).forEach(([id, qty]) => {
    const product = PRODUCTS.find((p) => p.id === id);
    if (!product) return;
    const lineTotal = product.price * qty;
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${product.name}</td>
      <td>${product.price.toFixed(2)}</td>
      <td>${qty}</td>
      <td>${lineTotal.toFixed(2)}</td>
    `;
    itemsBody.appendChild(tr);
  });

  const format = (n) => n.toFixed(2);

  const subEl = document.getElementById("invoice-subtotal");
  const discEl = document.getElementById("invoice-discount");
  const taxEl = document.getElementById("invoice-tax");
  const totalEl = document.getElementById("invoice-total");

  if (subEl) subEl.textContent = format(totals.subtotal);
  if (discEl) discEl.textContent = format(totals.discount);
  if (taxEl) taxEl.textContent = format(totals.tax);
  if (totalEl) totalEl.textContent = format(totals.total);

  document.getElementById("invoice-customer-name").textContent =
    customer.name || "—";
  document.getElementById("invoice-customer-address").textContent =
    customer.address || "—";
  document.getElementById("invoice-customer-phone").textContent =
    customer.phone || "—";
  document.getElementById("invoice-payment-method").textContent =
    payment.method || "—";
  document.getElementById("invoice-amount-paid").textContent =
    (payment.amountPaid || 0).toFixed(2);

  const date = new Date(createdAt);
  document.getElementById("invoice-date").textContent =
    date.toLocaleDateString();
  document.getElementById("invoice-number").textContent =
    "JAM-" + date.getTime().toString().slice(-6);
}

// ---------- Init ----------
document.addEventListener("DOMContentLoaded", () => {
  renderProducts();
  renderCart();
  renderSummary();
  renderInvoice();
});
